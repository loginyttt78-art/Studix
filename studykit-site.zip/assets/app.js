const $ = s => document.querySelector(s);
const tip = document.getElementById("toast");
let tt;
function toast(m){ tip.textContent = m; tip.style.display = "block"; clearTimeout(tt); tt = setTimeout(() => tip.style.display = "none", 3500); }
function save(filename, blob){
  const url = URL.createObjectURL(blob), a = document.createElement("a");
  a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  toast("Saved " + filename);
}
function loadImg(file){
  return new Promise((res, rej) => {
    const u = URL.createObjectURL(file), im = new Image();
    im.onload = () => res(im); im.onerror = () => rej(new Error("bad image")); im.src = u;
  });
}
function fmt(n){ return n > 1048576 ? (n / 1048576).toFixed(2) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB"; }
